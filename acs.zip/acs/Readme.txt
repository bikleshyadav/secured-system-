--Secure Authentication System
Version 1.0

--Features:
User registration with email verification
Password strength (8-digit,uppercase, lowercase, number, special character)
Security question 
Secure login with reCAPTCHA (v2)
Password reset functionality with email verification
Account security features (lockout, password expiration)
Client-side and server-side validation

--Technical Requirements
PHP 7.0 or higher
MySQL 5.7 or higher
Web server (Apache recommended)
SMTP server access for email functionality

--Installation
Clone the repository to your web server directory
Import the database schema using database.sql
Configure database connection in db_connection.php
Update email settings in signup.php and reset_password.php
Install dependencies using Composer

--Configuration
Database configuration (db_connection.php):
Email configuration (in relevant PHP files):

--Usage
Access the system through a web browser
Users can:
Register new accounts
Log in to existing accounts
Reset forgotten passwords
Update passwords when expired

--Security Features
Complex password requirements
Email verification for new accounts
reCAPTCHA protection against automated attacks
Account lockout after multiple failed attempts
Password expiration enforcement
Avoid common password

--File Structure
index.html - Main interface
styles.css - CSS styling
scripts.js - Client-side JavaScript
PHP files:
signup.php - Handles user registration
login.php - Processes login attempts
verify.php - Email verification
reset_password.php - Password reset
changePassword.php - Updates passwords



