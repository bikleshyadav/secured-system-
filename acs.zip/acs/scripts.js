// Toggle Password Visibility
function togglePassword(id) {
    const passwordField = document.getElementById(id);
    const toggleButton = passwordField.nextElementSibling;
    if (passwordField.type === "password") {
        passwordField.type = "text";
        toggleButton.textContent = "🙈";
    } else {
        passwordField.type = "password";
        toggleButton.textContent = "👁️";
    }
}

var userSignUpEmail;
var isFromReset = false;

// Switch between forms
document.getElementById('goToSignIn').addEventListener('click', function (e) {
    e.preventDefault();
    showForm('signin-form');
});

document.getElementById('goToSignUp').addEventListener('click', function (e) {
    e.preventDefault();
    showForm('signup-form');
});

document.getElementById('forgotPassword').addEventListener('click', function (e) {
    e.preventDefault();
    showForm('reset-password-form');
});

document.getElementById('backToSignIn').addEventListener('click', function (e) {
    e.preventDefault();
    showForm('signin-form');
});

function showForm(formId) {
    const forms = ['signin-form', 'signup-form', 'reset-password-form', 'verification-form', 'new-password-form'];
    forms.forEach(id => {
        const formElement = document.getElementById(id);

        if (formElement) {
            // Only try to change style if the element exists
            formElement.style.display = id === formId ? 'block' : 'none';
        } else {
            console.warn(`Form with id "${id}" not found in the DOM.`);
        }
    });
}

// Sign-Up Form Submission and Validation
document.getElementById('signup-form').addEventListener('submit', function (e) {
    e.preventDefault();

    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;
    const confirmPassword = document.getElementById('confirmPassword').value;
    const fullName = document.getElementById('fullName').value;
    // const email = document.getElementById('email').value;
    const phoneNumber = document.getElementById('phoneNumber').value;
    const gender = document.getElementById('gender').value;
    const country = document.getElementById('country').value;
    const securityQuestion = document.getElementById('securityQuestion').value;
    const securityAnswer = document.getElementById('securityAnswer').value;
    // const password = document.getElementById('password').value;
    // const confirmPassword = document.getElementById('confirmPassword').value;

    // List of common or weak passwords
    const commonPasswords = [
        "Password@123", "Name$456", "123456789", "Form%111", "Abc!123", "Keyword#1",
        "admin##11", "letmein!1", "wel@come1", "monkey&123", "iloveyou123@", "football000#"
    ];

    if (password.length < 8) {
        alert('Password must be at least 8 characters long.');
        return;
    }

    const passwordRegex = /^(?=.*[A-Z])(?=.*[a-z])(?=.*\d)(?=.*[!@#$%^&*()]).{8,}$/;
    if (!passwordRegex.test(password)) {
        alert('Password must contain at least one uppercase letter, one lowercase letter, one number, and one special character.');
        return;
    }

    if (password !== confirmPassword) {
        alert('Passwords do not match.');
        return;
    }

    // Simulate user registration
    // alert(`A verification code has been sent to your email: ${email}.`);

    // showForm('verification-form');

    const verificationCode = Math.floor(100000 + Math.random() * 900000);
    // localStorage.setItem('verificationCode', verificationCode.toString());
    // console.log(`Verification code: ${verificationCode}`); // For testing

    const formData = new FormData();
    formData.append('full_name', fullName);
    formData.append('email', email);
    formData.append('phone_number', phoneNumber);
    formData.append('gender', gender);
    formData.append('country', country);
    formData.append('security_question', securityQuestion);
    formData.append('security_answer', securityAnswer);
    formData.append('password', password);
    formData.append('verification_code', verificationCode.toString());

    fetch('signup.php', {
        method: 'POST',
        body: formData
    })
        .then(response => response.text())  // assuming the server responds with text
        .then(data => {
            console.log(data);  // log response from PHP (for testing)
            if (data.includes('success')) { // Assuming PHP echoes "success" on successful registration
                userSignUpEmail = email;
                alert(`Registration successful. A verification code has been sent to your email: ${email}.`);
                showForm('verification-form')// Redirect to login page
            } else {
                alert('Registration failed: ' + data);  // Show error message
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('An error occurred during registration.');
        });
});

// Login with reCAPTCHA
document.getElementById('signin-form').addEventListener('submit', function (e) {
    e.preventDefault();

    const email = document.getElementById('signin-email').value;
    const password = document.getElementById('signin-password').value;
    const recaptchaResponse = grecaptcha.getResponse();

    if (!recaptchaResponse) {
        alert('Please complete the reCAPTCHA.');
        return;
    }

    if (isUserBlocked()) {
        alert("You are blocked from logging in for 6 hours.");
        return;
    }

    // Simulate sending the login data and reCAPTCHA response to your server
    console.log('Login attempt:', { email, password, recaptchaResponse });
    // alert('Login credentials and reCAPTCHA response would be sent to the server for verification.');
    console.log('Password: ', {password})
    // Reset the reCAPTCHA
    grecaptcha.reset();
    // Prepare the data to send to login.php
    const formData = new FormData();
    formData.append('email', email);
    formData.append('password', password); // Send the reCAPTCHA response as well

    // Use fetch to send data to login.php
    fetch('login.php', {
        method: 'POST',
        body: formData,
    })
        .then(response => {
            console.log('Raw response:', response);
            return response.json();
        }) // Assuming the server returns JSON
        .then(data => {
            console.log('data response:', data);
            if (data.success) {
                alert('Login successful!');
                resetLoginAttempts();
                // Redirect to the dashboard
                document.getElementById('signin-form').style.display = 'none';
                document.getElementById('dashboard').style.display = 'block';
            } else {
                handleFailedLogin();
                // alert('Login failed: ' + data.message);
            }
        })
        .catch(error => {
            console.error('Error during login:', error);
            handleFailedLogin();
            // alert('An error occurred during login. Please try again later.');
        });

});

// Maximum login attempts
const maxAttempts = 5;

// Function to handle sign-in attempts
function signIn() {
    const registeredEmail = "user@example.com"; // Replace this with dynamic email from registration
    const registeredPassword = "Password123!";  // Replace this with dynamic password from registration

    const enteredEmail = document.getElementById('signin-email').value;
    const enteredPassword = document.getElementById('signin-password').value;
    console.log("in signin");
    // Check if the user is blocked
    if (isUserBlocked()) {
        alert("You are blocked from logging in for 6 hours.");
        return;
    }

    // Check if email and password match the registered credentials
    if (enteredEmail === registeredEmail && enteredPassword === registeredPassword) {
        resetLoginAttempts(); // Reset login attempts on successful login
        document.getElementById('signin-form').style.display = 'none';
        document.getElementById('dashboard').style.display = 'block';
    } else {
        handleFailedLogin();
    }
}

// Function to check if password is expired (not changed in 30 days)
function isPasswordExpired() {
    const lastPasswordChange = localStorage.getItem('lastPasswordChange');
    if (!lastPasswordChange) {
        // If there's no last password change date, force change
        return true;
    }
    const currentTime = new Date().getTime();
    const thirtyDaysInMs = 30 * 24 * 60 * 60 * 1000; // 30 days in milliseconds
    return (currentTime - lastPasswordChange) > thirtyDaysInMs;
}

// Function to show the password change reminder modal
function showPasswordChangeReminder() {
    document.getElementById('signin-form').style.display = 'none';
    document.getElementById('change-password-reminder').style.display = 'block';
}

// Function to handle password change reminder
function updatePasswordReminder() {
    const newPassword = document.getElementById('new-password-reminder').value;
    const confirmPassword = document.getElementById('confirm-password-reminder').value;

    const passwordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;

    if (!passwordRegex.test(newPassword)) {
        alert("Password must be at least 8 characters long, contain an uppercase letter, a lowercase letter, a number, and a special character.");
        return;
    }

    if (newPassword !== confirmPassword) {
        alert("Passwords do not match!");
    } else {
        // Update password change date and proceed to dashboard
        localStorage.setItem('lastPasswordChange', new Date().getTime());
        alert("Password changed successfully!");
        document.getElementById('change-password-reminder').style.display = 'none';
        document.getElementById('dashboard').style.display = 'block';
    }
}

// Function to handle failed login attempts
function handleFailedLogin() {
    let attempts = localStorage.getItem('loginAttempts') || 0;
    attempts = parseInt(attempts) + 1;

    if (attempts >= maxAttempts) {
        // Block user for 6 hours
        const blockTime = new Date().getTime() + 6 * 60 * 60 * 1000; // 6 hours in milliseconds
        localStorage.setItem('blockTime', blockTime);
        alert("You have been blocked for 6 hours due to multiple failed login attempts.");
    } else {
        localStorage.setItem('loginAttempts', attempts);
        const remainingAttempts = maxAttempts - attempts;
        alert(`Incorrect email or password. You have ${remainingAttempts} attempt(s) remaining.`);
    }
}

// Function to check if the user is blocked
function isUserBlocked() {
    const blockTime = localStorage.getItem('blockTime');
    if (blockTime) {
        const currentTime = new Date().getTime();
        if (currentTime < blockTime) {
            return true;
        } else {
            // Block time has expired, reset block and attempts
            resetLoginAttempts();
            return false;
        }
    }
    return false;
}

// Function to reset login attempts and block time
function resetLoginAttempts() {
    localStorage.removeItem('loginAttempts');
    localStorage.removeItem('blockTime');
}

function verifyCode() {
    const inputCode = document.getElementById('verificationCode').value;
    // const storedCode = localStorage.getItem('verificationCode');
    // const resetCode = localStorage.getItem('resetVerificationCode');

    if (inputCode === "") {
        alert("Please enter a verification code.");
        return;
    }

    const formData = new FormData();
    formData.append('verification_code', inputCode);
    formData.append('email', userSignUpEmail);

    fetch('verify.php', {
        method: 'POST',  // Use POST method
        body: formData   // Send the form data
    })
        .then(response => response.json())  // Parse the JSON response from the server
        .then(data => {
            if (data.success) {
                // If verification is successful
                alert("Verification successful!");
                

                const form = document.getElementById('verification-form');
                Array.from(form.elements).forEach(element => {
                    if (element.tagName === "INPUT") {
                        element.value = ''; // Clear input fields
                    }
                });
                if (isFromReset) {
                    showForm('new-password-form')
                } else {
                    userSignUpEmail = '';
                    showForm('signin-form')
                }
                isFromReset = null;
            } else {
                // If verification fails
                alert("Invalid verification code.");
            }
        })
        .catch((error) => {
            console.error('Error:', error);
            alert("An error occurred while verifying the code.");
        });

    // if (inputCode === storedCode) {
    //     alert('Email verified successfully! You can now log in.');
    //     showForm('signin-form');
    // } else if (inputCode === resetCode) {
    //     console.log("here ")
    //     alert('Verification successful! Please enter your new password.');
    //     showForm('new-password-form');
    // } else {
    //     alert('Incorrect verification code. Please try again.');
    // }
}

// Reset Password Process
document.getElementById('reset-password-form').addEventListener('submit', function (e) {
    e.preventDefault();
    isFromReset = true;
    const resetEmail = document.getElementById('resetEmail').value;
    sendResetVerificationEmail(resetEmail);
});

function sendResetVerificationEmail(email) {
    // alert('A verification code has been sent to your registered email.');
    const verificationCode = Math.floor(100000 + Math.random() * 900000);
    userSignUpEmail = email;
    const formData = new FormData();
    formData.append('verification_code', verificationCode);
    formData.append('email', email);


    fetch('reset_password.php', {
        method: 'POST',
        body: formData,
    })
    .then(response => response.text()) // First, get the raw text response
    .then(text => {
        console.log('Raw response:', text); // Log it to inspect the response
        return JSON.parse(text); // Try to parse the JSON from the response
    })
    .then(data => {
            if (data.success) {
                alert(`Verificaiton code has been sent to ${email}`);
                const form = document.getElementById('reset-password-form');
                Array.from(form.elements).forEach(element => {
                    if (element.tagName === "INPUT") {
                        element.value = ''; // Clear input fields
                    }
                });
                // Redirect to the dashboard
                showForm('verification-form');

            } else {
                alert('Error: ' + data.message);
            }
        })
        .catch(error => {
            console.error('Error during reset:', error);
            alert('An error occurred during reset. Please try again later.');
        });
    // localStorage.setItem('resetVerificationCode', verificationCode.toString());
    // console.log(`Reset verification code: ${verificationCode}`); // For testing
    // showForm('verification-form');
}

// Update New Password Submission
// document.getElementById('new-password-form').addEventListener('submit', function (e) {
//     e.preventDefault();
//     const newPassword = document.getElementById('newPassword').value;
//     const confirmNewPassword = document.getElementById('confirmNewPassword').value;

//     if (newPassword.length < 8) {
//         alert('Password must be at least 8 characters long.');
//         return;
//     }

//     const passwordRegex = /^(?=.*[A-Z])(?=.*[a-z])(?=.*\d)(?=.*[!@#$%^&*()]).{8,}$/;
//     if (!passwordRegex.test(newPassword)) {
//         alert('Password must contain at least one uppercase letter, one lowercase letter, one number, and one special character.');
//         return;
//     }

//     if (newPassword !== confirmNewPassword) {
//         alert('Passwords do not match.');
//         return;
//     }

//     alert('Password updated successfully! You can now sign in with your new password.');
//     showForm('signin-form');
// });

// Function to update profile details
function updateProfile() {
    alert("Profile updated successfully!");
}

// Function to validate and change password
function changePassword() {
    const newPassword = document.getElementById('new-password-dashboard').value;
    const confirmPassword = document.getElementById('confirm-password-dashboard').value;

    const passwordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;

    if (!passwordRegex.test(newPassword)) {
        alert("Password must be at least 8 characters long, contain an uppercase letter, a lowercase letter, a number, and a special character.");
        return;
    }

    if (newPassword !== confirmPassword) {
        alert("Passwords do not match!");S
    } else {
        alert("Password changed successfully!");
    }
}

function changeForgotPassword() {
    const newPassword = document.getElementById('new-password-forgot').value;
    const confirmPassword = document.getElementById('confirm-password-forgot').value;

    const passwordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;

    if (!passwordRegex.test(newPassword)) {
        alert("Password must be at least 8 characters long, contain an uppercase letter, a lowercase letter, a number, and a special character.");
        return;
    }

    if (newPassword !== confirmPassword) {
        alert("Passwords do not match!");
        return
    }

    const formData = new FormData();
    formData.append('newPassword', newPassword);
    formData.append('email', userSignUpEmail);

    // Send request to changePassword.php
    fetch('changePassword.php', {
        method: 'POST',
        body: formData,
    })
        .then(response => response.text()) // First, get the raw text response
        .then(text => {
            console.log('Raw response:', text); // Log it to inspect the response
            return JSON.parse(text); // Try to parse the JSON from the response
        })
        .then(data => {
            if (data.success) {
                userSignUpEmail = '';
                alert('Password changed successfully.');
                document.getElementById('new-password-forgot').value='';
                document.getElementById('confirm-password-forgot').value ='';


                document.getElementById('new-password-form').style.display = 'none';
                document.getElementById('signin-form').style.display = 'block';
            } else {
                alert('Error: ' + data.message);
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('An error occurred. Please try again.');
        });
}

// Function to logout and redirect to sign-in page
function logout() {
    document.getElementById('dashboard').style.display = 'none';
    document.getElementById('signin-form').style.display = 'block';
}