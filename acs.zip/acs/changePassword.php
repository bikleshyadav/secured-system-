<?php
session_start();
include 'db_connection.php'; // Adjust the path to your database connection file

// Check if the request method is POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get the new password from the POST request
    $newPassword = $_POST['newPassword'];
    $email = $_POST['email']; // Assuming the user is logged in and you have their user_id stored in session

    // // Validate that the user is logged in
    // if (!isset($userId)) {
    //     echo json_encode(['success' => false, 'message' => 'User is not logged in.']);
    //     exit();
    // }

    // // Validate the new password (you can perform more checks here if needed)
    // if (empty($newPassword)) {
    //     echo json_encode(['success' => false, 'message' => 'New password is required.']);
    //     exit();
    // }
    $hashed_password = password_hash($newPassword, PASSWORD_BCRYPT);
    // In this case, we're storing the password as plain text (though hashing is recommended)
    // Update the user's password in the database
    $sql = "UPDATE user SET password = ? WHERE email = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $hashed_password, $email);

    if ($stmt->execute()) {
        // Password successfully updated
        echo json_encode(['success' => true, 'message' => 'Password successfully updated.']);
    } else {
        // Error updating the password
        echo json_encode(['success' => false, 'message' => 'Error updating password.']);
    }

    // Close the statement and connection
    $stmt->close();
    $conn->close();
} else {
    // Invalid request method
    echo json_encode(['success' => false, 'message' => 'Invalid request method.']);
}
?>