<?php
session_start();
include 'db_connection.php';

$response = [];

// Get email and verification code from the user (through form submission)
$user_email = $_POST['email'];
$user_verification_code = $_POST['verification_code'];

// Prepare the SQL statement
$sql = "SELECT verification_code FROM user WHERE email = ?";

// Use prepared statements to prevent SQL injection
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $user_email);
$stmt->execute();
$result = $stmt->get_result();

// Check if the email exists in the database
if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $db_verification_code = $row['verification_code'];

    // Compare the verification code from the user with the one in the database
    if ($user_verification_code === $db_verification_code) {
        

        // Update the user record to mark as verified (optional, if you have an 'is_verified' column)
        $update_sql = "UPDATE user SET verification_code = NULL WHERE email = ?";
        $update_stmt = $conn->prepare($update_sql);
        $update_stmt->bind_param("s", $user_email);
        $update_stmt->execute();

        echo json_encode(['success'=> true]);

        // You can also redirect the user to a success page
        // header('Location: success.php');
    } else {
        echo json_encode(['success'=> true, 'message'=> 'Invalid verification code']);
    }
} else {
    echo json_encode(['success'=> true, 'message'=> 'No user found with this email.']);
    echo "No user found with this email.";
}

// Close the statement and connection
$stmt->close();
$conn->close();
?>
