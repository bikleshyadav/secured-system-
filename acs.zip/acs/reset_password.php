<?php

require 'vendor/autoload.php';


use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;


session_start();
include 'db_connection.php'; // Include database connection

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $user_email = $_POST['email'];
    $verification_code = $_POST['verification_code'];

    // Check if the email exists in the database
    $sql = "SELECT email FROM user WHERE email = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $user_email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {

        // Update the user table with the new verification code
        $update_sql = "UPDATE user SET verification_code = ? WHERE email = ?";
        $update_stmt = $conn->prepare($update_sql);
        $update_stmt->bind_param("ss", $verification_code, $user_email);

        if ($update_stmt->execute()) {
            if (sendVerificationEmail($user_email, $verification_code)) {
                echo json_encode(['success' => true, 'message' => 'Verification code sent to your email.']);
            } else {
                echo json_encode(['success' => false, 'message' => 'Error sending email.']);
            }
        } else {
            echo json_encode(['success' => false, 'message' => 'Error updating verification code. Please try again.']);
        }
    } else {
        // If email does not exist in the database
        echo json_encode(['success' => false, 'message' => 'No user found with this email.']);
    }


    // Close statement and connection
    $stmt->close();
    $conn->close();
}

function sendVerificationEmail($email, $verification_code)
{
    $mail = new PHPMailer(true);

    try {

        // systemsecure93@gmail.com
        // bikleshyadab9@gmail.com
        //Server settings  
        $mail-> isSMTP();                                         // Send using SMTP
        $mail->Host       = 'smtp.gmail.com';                       // Set the SMTP server to send through
        $mail->SMTPAuth   = true;                                   // Enable SMTP authentication
        $mail->Username   = 'thebookswap1@gmail.com';                 // SMTP username (your Gmail account)
        $mail->Password   = 'ltohlhzyykyzshnd';                  // SMTP password (your Gmail app password)
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;         // Enable TLS encryption
        $mail->Port       = 587;                                    // TCP port to connect to

        //Recipients
        $mail->setFrom('thebookswap1@gmail.com', 'Secure System');
        $mail->addAddress($email);                                  // Add a recipient

        // Content
        $mail->isHTML(true);                                        // Set email format to HTML
        $mail->Subject = 'Verify Your Email Address';
        $mail->Body    = 'Thank you for signing up. Please use the following code to verify your account: <b>' . $verification_code . '</b>';
        $mail->AltBody = 'Thank you for signing up. Please use the following code to verify your account: ' . $verification_code;

        $mail->send();
        return true;
    } catch (Exception $e) {
        error_log("Mailer Error: {$mail->ErrorInfo}");  // Log the error instead of displaying it
        return false;
    }
}
