<?php
require 'vendor/autoload.php';


use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;


// Database credentials
$servername = "localhost"; // Change if your DB is hosted elsewhere
$username = "root"; // Your DB username
$password = ""; // Your DB password
$dbname = "securesystem"; // Your DB name

// Create a connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Collect form data
    $full_name = $_POST['full_name'];
    $email = $_POST['email'];
    $phone_number = $_POST['phone_number'];
    $gender = $_POST['gender'];
    $country = $_POST['country'];
    $security_question = $_POST['security_question'];
    $security_answer = $_POST['security_answer'];
    $password = $_POST['password'];
    $verification_code = $_POST['verification_code'];

    $hashed_password = password_hash($password, PASSWORD_BCRYPT);
    // Prepare and bind SQL statement
    $stmt = $conn->prepare("INSERT INTO user (full_name, email, phone_number, gender, country, security_question, security_answer, password, verification_code) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("sssssssss", $full_name, $email, $phone_number, $gender, $country, $security_question, $security_answer, $hashed_password, $verification_code);

    // Execute the query
    if ($stmt->execute()) {
        sendVerificationEmail($email, $verification_code);
        echo "New user created successfully!";
    } else {
        echo "Error: " . $stmt->error;
    }

    // Close statement and connection
    $stmt->close();
    $conn->close();
}

function sendVerificationEmail($email, $verification_code) {
    $mail = new PHPMailer(true);

    try {

        // systemsecure93@gmail.com
        // bikleshyadab9@gmail.com
        //Server settings
        $mail->SMTPDebug = 2;                                       // Disable verbose debug output
        $mail->isSMTP();                                            // Send using SMTP
        $mail->Host       = 'smtp.gmail.com';                       // Set the SMTP server to send through
        $mail->SMTPAuth   = true;                                   // Enable SMTP authentication
        $mail->Username   = 'thebookswap1@gmail.com';                 // SMTP username (your Gmail account)
        $mail->Password   = 'ltohlhzyykyzshnd';                  // SMTP password (your Gmail app password)
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;         // Enable TLS encryption
        $mail->Port       = 587;                                    // TCP port to connect to

        //Recipients
        $mail->setFrom('thebookswap1@gmail.com', 'Secure System');
        $mail->addAddress($email);                                  // Add a recipient

        // Content
        $mail->isHTML(true);                                        // Set email format to HTML
        $mail->Subject = 'Verify Your Email Address';
        $mail->Body    = 'Thank you for signing up. Please use the following code to verify your account: <b>' . $verification_code . '</b>';
        $mail->AltBody = 'Thank you for signing up. Please use the following code to verify your account: ' . $verification_code;

        $mail->send();
        echo 'Verification email has been sent.';
    } catch (Exception $e) {
        echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
    }
}
?>
